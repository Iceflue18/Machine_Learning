import nltk
nltk.download()